import * as THREE from 'https://threejsfundamentals.org/threejs/resources/threejs/r115/build/three.module.js';
import { OrbitControls } from 'https://threejsfundamentals.org/threejs/resources/threejs/r115/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'https://threejsfundamentals.org/threejs/resources/threejs/r115/examples/jsm/loaders/GLTFLoader.js';
// import { GUI } from 'https://threejsfundamentals.org/threejs/../3rdparty/dat.gui.module.js';
import { RectAreaLightUniformsLib } from 'https://threejsfundamentals.org/threejs/resources/threejs/r115/examples/jsm/lights/RectAreaLightUniformsLib.js';

class App {
    constructor() {
        const divContainer = document.querySelector("#webgl-container");
        this._divContainer = divContainer;

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setPixelRatio(window.devicePixelRatio);
        divContainer.appendChild(renderer.domElement);

        renderer.shadowMap.enabled = true;
        renderer.setClearColor(0xb7ecff); // 배경색.
        this._renderer = renderer;
        const scene = new THREE.Scene();
        this._scene = scene;
        this._clock = new THREE.Clock();

        this._loadModel();
        // this._setupModel();
        this._setupCamera(); //camera가 orbitctrl보다 위에 있어야함.
        this._setupControls();
        this._setupLight();

        window.addEventListener('resize', this.resize.bind(this));
        this.resize();

        requestAnimationFrame(this.render.bind(this));
    }

    _loadModel() {
        const RobotArms = new GLTFLoader();
        let MixerRoom;
    
        RobotArms.load('./assets/Gen_MixerRoom_16c.gltf', (gltf) => {
            MixerRoom = new THREE.Object3D();
            MixerRoom.position.set(0, 0, 0);
    
            // Loop through all the meshes in the GLTF and add an emissive material to them
            gltf.scene.traverse((node) => {
                if (node.isMesh) {
                    node.material.emissive = new THREE.Color(0xffffff); // set emissive color to white
                    node.material.emissiveIntensity = 0.1; // set emissive intensity to 2
                }
            });
    
            MixerRoom.add(gltf.scene);
            setTimeout(() => {
                this._scene.add(MixerRoom);
            }, 1000);
            this.arm1 = MixerRoom;
        });
    
    }
    

    // _setupModel() {
    //     this._createTable();
    // }

    // _createTable() {
    //     const flatformscale = { x: 25, y: 1, z: 25 };
    //     const position = { x: 0, y: -flatformscale.y / 2, z: 0 };

    //     const tableGeometry = new THREE.BoxGeometry();
    //     // const mesh = this._modelRepository.getObjectByName("board");

    //     // const tableGeometry = new THREE.PlaneGeometry();
    //     // tableGeometry.rotateX(-Math.PI / 180 * 90)
    //     const tableTexture = new THREE.TextureLoader().load('checkerboard.png');
    //     // const mapbump = new THREE.TextureLoader().load('checkerboardN.png');
    //     const mapbump = new THREE.TextureLoader().load('checkerboard_bump.png');
    //     tableTexture.wrapS = THREE.RepeatWrapping;
    //     tableTexture.wrapT = THREE.RepeatWrapping;
    //     tableTexture.repeat.set(5, 5); // change the numbers to adjust the size of the checkered pattern
    //     mapbump.wrapS = THREE.RepeatWrapping;
    //     mapbump.wrapT = THREE.RepeatWrapping;
    //     mapbump.repeat.set(5, 5); // change the numbers to adjust the size of the checkered pattern
    //     const tableMaterial = new THREE.MeshStandardMaterial({
    //         // const tableMaterial = new THREE.MeshPhysicalMaterial({
    //         map: tableTexture,
    //         // normalMap: mapbump,
    //         bumpMap: mapbump,
    //         bumpScale: 0.1,

    //         roughness: 0.3,
    //         // metalness: 0.2,
    //         emissive: 0x202020,
    //         // emissive: 0x505050,
    //     });
    //     const table = new THREE.Mesh(tableGeometry, tableMaterial);

    //     table.position.set(position.x, position.y, position.z);
    //     table.scale.set(flatformscale.x, flatformscale.y, flatformscale.z);

    //     table.receiveShadow = true;
    //     this._scene.add(table);
    // }

    _setupCamera() {
        const camera = new THREE.PerspectiveCamera(
            50,
            window.innerWidth / window.innerHeight,
            0.1,
            100
        );
        camera.position.set(15, 20, 20);
        this._camera = camera;
    }

    _setupControls() {
        const orbCtrl = new OrbitControls(this._camera, this._divContainer);
        orbCtrl.target.set(0, 8, 0); // 카메라의 lookat을 대신함.
        orbCtrl.update();            // 카메라 초기위치를 위 좌표로 하게 해줌.
    }

    _setupLight() {
        RectAreaLightUniformsLib.init();

        const RectLightintensity = 5;
        const RectLightX = 16;
        const RectLightY = 2;
        const PosZ_1 = 10;
        const PosZ_2 = -10;

        const rectAreaLight1a = new THREE.RectAreaLight(0xffffff, RectLightintensity, RectLightX, RectLightY);
        rectAreaLight1a.position.set(-4, 15, PosZ_1);
        rectAreaLight1a.lookAt(0, 0, PosZ_1);
        this._scene.add(rectAreaLight1a);

        // const rectAreaLightHelper1a = new THREE.PointLightHelper(rectAreaLight1a);
        // this._scene.add(rectAreaLightHelper1a);

        const rectAreaLight2a = new THREE.RectAreaLight(0xffffff, RectLightintensity, RectLightX, RectLightY);
        rectAreaLight2a.position.set(4, 15, PosZ_1);
        rectAreaLight2a.lookAt(0, 0, PosZ_1);
        this._scene.add(rectAreaLight2a);

        // const rectAreaLightHelper2a = new THREE.PointLightHelper(rectAreaLight2a);
        // this._scene.add(rectAreaLightHelper2a);

        const rectAreaLight3a = new THREE.RectAreaLight(0xffffff, RectLightintensity, RectLightX, RectLightY);
        rectAreaLight3a.position.set(-12, 15, PosZ_1);
        rectAreaLight3a.lookAt(0, 0, PosZ_1);
        this._scene.add(rectAreaLight3a);

        // const rectAreaLightHelper3a = new THREE.PointLightHelper(rectAreaLight3a);
        // this._scene.add(rectAreaLightHelper3a);

        const rectAreaLight4a = new THREE.RectAreaLight(0xffffff, RectLightintensity, RectLightX, RectLightY);
        rectAreaLight4a.position.set(12, 15, PosZ_1);
        rectAreaLight4a.lookAt(0, 0, PosZ_1);
        this._scene.add(rectAreaLight4a);

        // const rectAreaLightHelper4 = new THREE.PointLightHelper(rectAreaLight4a);
        // this._scene.add(rectAreaLightHelper4);

        const rectAreaLight1b = new THREE.RectAreaLight(0xffffff, RectLightintensity, RectLightX, RectLightY);
        rectAreaLight1b.position.set(-4, 20, PosZ_2);
        rectAreaLight1b.lookAt(0, 0, PosZ_2);
        this._scene.add(rectAreaLight1b);
        
        // const rectAreaLightHelper1b = new THREE.PointLightHelper(rectAreaLight1b);
        // this._scene.add(rectAreaLightHelper1b);
        
        const rectAreaLight2b = new THREE.RectAreaLight(0xffffff, RectLightintensity, RectLightX, RectLightY);
        rectAreaLight2b.position.set(4, 20, PosZ_2);
        rectAreaLight2b.lookAt(0, 0, PosZ_2);
        this._scene.add(rectAreaLight2b);
        
        // const rectAreaLightHelper2b = new THREE.PointLightHelper(rectAreaLight2b);
        // this._scene.add(rectAreaLightHelper2b);
        
        const rectAreaLight3b = new THREE.RectAreaLight(0xffffff, RectLightintensity, RectLightX, RectLightY);
        rectAreaLight3b.position.set(-12, 20, PosZ_2);
        rectAreaLight3b.lookAt(0, 0, PosZ_2);
        this._scene.add(rectAreaLight3b);
        
        // const rectAreaLightHelper3b = new THREE.PointLightHelper(rectAreaLight3b);
        // this._scene.add(rectAreaLightHelper3b);
        
        const rectAreaLight4b = new THREE.RectAreaLight(0xffffff, RectLightintensity, RectLightX, RectLightY);
        rectAreaLight4b.position.set(12, 20, PosZ_2);
        rectAreaLight4b.lookAt(0, 0, PosZ_2);
        this._scene.add(rectAreaLight4b);
        
        const rectAreaLightHelper4b = new THREE.PointLightHelper(rectAreaLight4b);
        this._scene.add(rectAreaLightHelper4b);

        const light0 = new THREE.DirectionalLight(0xffffff, 1);
        light0.position.set(-1, 10, -1);
        this._scene.add(light0);

        const pointLightintensity = 0.2;

        const light1 = new THREE.PointLight(0xffffff, pointLightintensity);
        light1.position.set(-10, 5, -10);
        this._scene.add(light1);
        // const light1Helper = new THREE.PointLightHelper(light1, 1);
        // this._scene.add(light1Helper);

        const light2 = new THREE.PointLight(0xffffff, pointLightintensity);
        light2.position.set(5, 10, 5);
        this._scene.add(light2);
        // const light2Helper = new THREE.PointLightHelper(light2, 1);
        // this._scene.add(light2Helper);

        const light3 = new THREE.PointLight(0xffffff, 2 * pointLightintensity);
        light3.position.set(-5, 13, 5);
        this._scene.add(light3);
        // const light3Helper = new THREE.PointLightHelper(light3, 1);
        // this._scene.add(light3Helper);

        const light4 = new THREE.PointLight(0xffffff, pointLightintensity);
        light4.position.set(5, 5, -5);
        this._scene.add(light4);
        // const light4Helper = new THREE.PointLightHelper(light4, 1);
        // this._scene.add(light4Helper);

        const lightH = new THREE.HemisphereLight(0xB1E1FF, 0xB97A20, 1);
        this._scene.add(lightH);
    }

    update(time) {
        time *= 0.001; // second unit
    }

    render() {
        const time = this._clock.getElapsedTime();
        this._renderer.render(this._scene, this._camera);
        this.update(time);

        requestAnimationFrame(this.render.bind(this));
    }

    resize() {
        const width = this._divContainer.clientWidth;
        const height = this._divContainer.clientHeight;

        this._camera.aspect = width / height;
        this._camera.updateProjectionMatrix();

        this._renderer.setSize(width, height);
    }
}

window.addEventListener('load', () => {
    new App();
});


